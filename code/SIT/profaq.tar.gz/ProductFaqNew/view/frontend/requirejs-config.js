var config = {
    map: {
        '*': {
            servicefaq:'SIT_ProductFaqNew/js/servicefaq'
        }
    },
    deps: ["jquery"]
};